/*
 * This file is part of MXE. See LICENSE.md for licensing information.
 */

#include <FreeImagePlus.h>

int main()
{
    fipImage fi;

    fi.setSize(FIT_BITMAP, 800, 600, 24);

    return 0;
}
