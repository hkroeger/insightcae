/*
 * This file is part of MXE. See LICENSE.md for licensing information.
 */

#include <lastfm/Track.h>

int main()
{
    lastfm::MutableTrack track;
    track.setTitle("Track");

    return 0;
}
